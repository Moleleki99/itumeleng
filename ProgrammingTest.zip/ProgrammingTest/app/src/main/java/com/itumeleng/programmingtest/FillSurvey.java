package com.itumeleng.programmingtest;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

import java.util.Map;

public class FillSurvey extends AppCompatActivity {

    private View mProgressView;
    private View mLoginFormView;
    private TextView tvLoad;

    EditText etSurname, etName, etPhone, etDate, etAge;
    CheckBox ckPasta, ckPizza, ckPapWors, ckChicken, ckBeef, ckOthers;

    Spinner spinner, spinner2, spinner3, spinner4;

    Button btnSubmit;

    int check = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fill_survey);

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
        tvLoad = findViewById(R.id.tvLoad);

        etSurname = findViewById(R.id.etSurname);
        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etDate = findViewById(R.id.etDate);
        etAge = findViewById(R.id.etAge);

        ckPasta = findViewById(R.id.ckPasta);
        ckPizza = findViewById(R.id.ckPizza);
        ckPapWors = findViewById(R.id.ckPapWors);
        ckChicken = findViewById(R.id.ckChicken);
        ckBeef = findViewById(R.id.ckBeef);
        ckOthers = findViewById(R.id.ckOther);

        spinner = findViewById(R.id.spinner);
        spinner2 = findViewById(R.id.spinner2);
        spinner3 = findViewById(R.id.spinner3);
        spinner4 = findViewById(R.id.spinner4);

        btnSubmit = findViewById(R.id.btnSubmit);





        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.eatout, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        String eatOut = spinner.getSelectedItem().toString();


        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.watchmovies, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        String watchMovies = adapter2.getItem(spinner2.getSelectedItemPosition()).toString();


        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.watchtv, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter3);
        String watchTv = adapter3.getItem(spinner3.getSelectedItemPosition()).toString();

        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this, R.array.listenradio, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        spinner4.setAdapter(adapter4);
        String listenRadio = adapter4.getItem(spinner4.getSelectedItemPosition()).toString();




        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etSurname.getText().toString().isEmpty() || etName.getText().toString().isEmpty()
                   || etPhone.getText().toString().isEmpty() || etDate.getText().toString().isEmpty()
                   || etAge.getText().toString().isEmpty())
                {
                    Toast.makeText(FillSurvey.this, "Please Enter All Fields!", Toast.LENGTH_SHORT).show();
                }
                else
                {

                    Participant participant = new Participant();
                    participant.setSurname(etSurname.getText().toString().trim());
                    participant.setName(etName.getText().toString().trim());
                    participant.setContactNumber(Integer.parseInt(etPhone.getText().toString().trim()));
                    participant.setDate(etDate.getText().toString().trim());
                    participant.setAge(Integer.parseInt(etAge.getText().toString().trim()));

                    boolean isChecked;
                    isChecked = ckPizza.isChecked();
                    participant.setPizza(isChecked);

                    isChecked = ckPasta.isChecked();
                    participant.setPasta(isChecked);

                    isChecked = ckPapWors.isChecked();
                    participant.setPapWors(isChecked);

                    isChecked = ckChicken.isChecked();
                    participant.setChicken(isChecked);

                    isChecked = ckBeef.isChecked();
                    participant.setBeef(isChecked);

                    isChecked = ckOthers.isChecked();
                    participant.setOther(isChecked);

                    participant.setEatOut(eatOut);
                    participant.setWatchMovies(watchMovies);
                    participant.setWatchTV(watchTv);
                    participant.setListenRadio(listenRadio);

                    tvLoad.setText("Submitting...Please...wait...");
                    showProgress(true);


                    Backendless.Persistence.of(Participant.class).findFirst(new AsyncCallback<Participant>() {
                        @Override
                        public void handleResponse(Participant participant) {

                            participant.setCount(participant.getCount() + 1);


                            Backendless.Persistence.save(participant, new AsyncCallback<Participant>() {
                                @Override
                                public void handleResponse(Participant response) {

                                    Participant newParticipant = new Participant();

                                    newParticipant.setSurname(etSurname.getText().toString().trim());
                                    newParticipant.setName(etName.getText().toString().trim());
                                    newParticipant.setContactNumber(Integer.parseInt(etPhone.getText().toString().trim()));
                                    newParticipant.setDate(etDate.getText().toString().trim());
                                    newParticipant.setAge(Integer.parseInt(etAge.getText().toString().trim()));

                                    boolean isChecked;
                                    isChecked = ckPizza.isChecked();
                                    newParticipant.setPizza(isChecked);

                                    isChecked = ckPasta.isChecked();
                                    newParticipant.setPasta(isChecked);

                                    isChecked = ckPapWors.isChecked();
                                    newParticipant.setPapWors(isChecked);

                                    isChecked = ckChicken.isChecked();
                                    newParticipant.setChicken(isChecked);

                                    isChecked = ckBeef.isChecked();
                                    newParticipant.setBeef(isChecked);

                                    isChecked = ckOthers.isChecked();
                                    newParticipant.setOther(isChecked);

                                    newParticipant.setEatOut(eatOut);
                                    newParticipant.setWatchMovies(watchMovies);
                                    newParticipant.setWatchTV(watchTv);
                                    newParticipant.setListenRadio(listenRadio);

                                    Backendless.Persistence.save(newParticipant, new AsyncCallback<Participant>() {
                                        @Override
                                        public void handleResponse(Participant response) {
                                            Toast.makeText(FillSurvey.this, "Survey submitted successfully!", Toast.LENGTH_SHORT).show();
                                            startActivity(new Intent(FillSurvey.this, MainActivity.class));
                                            showProgress(false);
                                            FillSurvey.this.finish();
                                        }

                                        @Override
                                        public void handleFault(BackendlessFault fault) {
                                            Toast.makeText(FillSurvey.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                                            showProgress(false);
                                        }
                                    });
                                }

                                @Override
                                public void handleFault(BackendlessFault fault) {
                                    Toast.makeText(FillSurvey.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                                    showProgress(false);
                                }
                            });
                        }

                        @Override
                        public void handleFault(BackendlessFault fault) {
                            Toast.makeText(FillSurvey.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                            showProgress(false);
                        }
                    });

                }
            }
        });


    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });

            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }
}