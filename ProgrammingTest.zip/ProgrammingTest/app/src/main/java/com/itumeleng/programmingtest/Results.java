package com.itumeleng.programmingtest;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.backendless.persistence.BackendlessDataQuery;
import com.backendless.persistence.DataQueryBuilder;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class Results extends AppCompatActivity {

    private View mProgressView;
    private View mLoginFormView;
    private TextView tvLoad;

    TextView tvTotalSurvey, tvAvgAge, tvOldest, tvYoungest, tvPizza, tvPasta, tvPapWors, tvEatOut, tvWatch, tvWatchTV, tvListenRadio;

    Button btnOk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
        tvLoad = findViewById(R.id.tvLoad);

        tvTotalSurvey = findViewById(R.id.tvTotalSurvey);
        tvAvgAge = findViewById(R.id.tvAvgAge);
        tvOldest = findViewById(R.id.tvOldest);
        tvYoungest = findViewById(R.id.tvYoungest);
        tvPizza = findViewById(R.id.tvPizza);
        tvPasta = findViewById(R.id.tvPasta);
        tvPapWors = findViewById(R.id.tvPapWors);
        tvEatOut = findViewById(R.id.tvEatOut);
        tvWatch = findViewById(R.id.tvWatch);
        tvWatchTV = findViewById(R.id.tvWatchTv);
        tvListenRadio = findViewById(R.id.tvListenRadio);

        tvLoad.setText("Getting all results...Please...wait...");
        showProgress(true);

        Backendless.Data.of("Participant").findFirst(new AsyncCallback<Map>() {
            @Override
            public void handleResponse(Map participantData) {

                int count = (int) participantData.get("count");

                tvTotalSurvey.setText("Total number of surveys: " + String.valueOf(count));

            }

            @Override
            public void handleFault(BackendlessFault fault) {

                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });

        DataQueryBuilder queryBuilder = DataQueryBuilder.create();
        queryBuilder.setProperties("age");
        Backendless.Data.of(Participant.class).find(queryBuilder, new AsyncCallback<List<Participant>>() {
            @Override
            public void handleResponse(List<Participant> participants) {

                double totalAge = 0;
                for (Participant participant : participants) {
                    totalAge += participant.getAge();
                }
                double averageAge = totalAge / participants.size();

                tvAvgAge.setText("Average age: "+ String.valueOf(averageAge));
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });

        DataQueryBuilder query = DataQueryBuilder.create();
        query.setSortBy("age DESC");
        query.setPageSize(1);

        Backendless.Data.of(Participant.class).find(query, new AsyncCallback<List<Participant>>() {
            @Override
            public void handleResponse(List<Participant> participants) {
                if (!participants.isEmpty()) {
                    Participant participant = participants.get(0);
                    int oldest = participant.getAge();
                    // Display the highest age in your app
                    tvOldest.setText("Oldest participant in the survey: " + String.valueOf(oldest));
                } else {
                    Toast.makeText(Results.this, "No participants found", Toast.LENGTH_SHORT).show();
                    showProgress(false);
                }
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });

        DataQueryBuilder query2 = DataQueryBuilder.create();
        query2.setSortBy("age ASC");
        query2.setPageSize(1);

        Backendless.Data.of(Participant.class).find(query2, new AsyncCallback<List<Participant>>() {
            @Override
            public void handleResponse(List<Participant> participants) {
                if (!participants.isEmpty()) {
                    Participant participant = participants.get(0);
                    int youngest = participant.getAge();

                    tvYoungest.setText("Youngest participant in the survey: " + String.valueOf(youngest));
                } else {
                    Toast.makeText(Results.this, "Error: No participant found" , Toast.LENGTH_SHORT).show();
                    showProgress(false);
                }
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });

        Backendless.Data.of(Participant.class).findFirst(new AsyncCallback<Participant>() {
            @Override
            public void handleResponse(Participant firstParticipant) {

                int totalCount = firstParticipant.getCount();

                DataQueryBuilder queryBuilder = DataQueryBuilder.create();
                queryBuilder.setWhereClause("pizza = true");

                Backendless.Data.of(Participant.class).getObjectCount(queryBuilder, new AsyncCallback<Integer>() {
                    @Override
                    public void handleResponse(Integer pizzaCount) {

                        double percentage = (pizzaCount * 100.0) / totalCount;

                        double roundedPercentage = Math.round(percentage * 10.0) / 10.0;

                        tvPizza.setText("Percentage of people who like Pizza: " + String.valueOf(roundedPercentage) + "%");
                        showProgress(false);
                    }

                    @Override
                    public void handleFault(BackendlessFault fault) {
                        Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                        showProgress(false);
                    }
                });
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });


        Backendless.Data.of(Participant.class).findFirst(new AsyncCallback<Participant>() {
            @Override
            public void handleResponse(Participant firstParticipant) {

                int totalCount = firstParticipant.getCount();

                DataQueryBuilder queryBuilder = DataQueryBuilder.create();
                queryBuilder.setWhereClause("pasta = true");

                Backendless.Data.of(Participant.class).getObjectCount(queryBuilder, new AsyncCallback<Integer>() {
                    @Override
                    public void handleResponse(Integer pastaCount) {
                        double percentage = (pastaCount * 100.0) / totalCount;

                        double roundedPercentage = Math.round(percentage * 10.0) / 10.0;

                        tvPasta.setText("Percentage of people who like Pasta: " + String.valueOf(roundedPercentage) + "%");
                    }

                    @Override
                    public void handleFault(BackendlessFault fault) {
                        Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                        showProgress(false);
                    }
                });
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });

        Backendless.Data.of(Participant.class).findFirst(new AsyncCallback<Participant>() {
            @Override
            public void handleResponse(Participant firstParticipant) {
                int totalCount = firstParticipant.getCount();

                DataQueryBuilder queryBuilder = DataQueryBuilder.create();
                queryBuilder.setWhereClause("papWors = true");

                Backendless.Data.of(Participant.class).getObjectCount(queryBuilder, new AsyncCallback<Integer>() {
                    @Override
                    public void handleResponse(Integer papCount) {

                        double percentage = (papCount * 100.0) / totalCount;

                        double roundedPercentage = Math.round(percentage * 10.0) / 10.0;

                        tvPapWors.setText("Percentage of people who like Pap & Wors: " + String.valueOf(roundedPercentage) + "%");
                    }

                    @Override
                    public void handleFault(BackendlessFault fault) {
                        Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                        showProgress(false);
                    }
                });
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });

        Backendless.Data.of(Participant.class).find(new AsyncCallback<List<Participant>>() {
            @Override
            public void handleResponse(List<Participant> participants) {
                int totalParticipants = participants.size();
                int totalRatings = 0;

                for (Participant participant : participants) {
                    String ratingString = participant.getEatOut();
                    int rating = extractRatingFromRatingString(ratingString);
                    totalRatings += rating;
                }

                Participant firstParticipant = participants.get(0);
                int count = firstParticipant.getCount();

                double averageRating = (double) totalRatings / count;
                double roundedAverageRating = Math.round(averageRating * 10.0) / 10.0;

                tvEatOut.setText("People like to eat out: " + String.valueOf(roundedAverageRating));
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });

        Backendless.Data.of(Participant.class).find(new AsyncCallback<List<Participant>>() {
            @Override
            public void handleResponse(List<Participant> participants) {
                int totalParticipants = participants.size();
                int totalRatings = 0;

                for (Participant participant : participants) {
                    String ratingString = participant.getWatchMovies();
                    int rating = extractRatingFromRatingString(ratingString);
                    totalRatings += rating;
                }

                Participant firstParticipant = participants.get(0);
                int count = firstParticipant.getCount();

                double averageRating = (double) totalRatings / count;
                double roundedAverageRating = Math.round(averageRating * 10.0) / 10.0;

                tvWatch.setText("People like to watch movies: " + String.valueOf(roundedAverageRating));
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });

        Backendless.Data.of(Participant.class).find(new AsyncCallback<List<Participant>>() {
            @Override
            public void handleResponse(List<Participant> participants) {
                int totalParticipants = participants.size();
                int totalRatings = 0;

                for (Participant participant : participants) {
                    String ratingString = participant.getWatchTV();
                    int rating = extractRatingFromRatingString(ratingString);
                    totalRatings += rating;
                }

                Participant firstParticipant = participants.get(0);
                int count = firstParticipant.getCount();

                double averageRating = (double) totalRatings / count;
                double roundedAverageRating = Math.round(averageRating * 10.0) / 10.0;

                tvWatchTV.setText("People like to watch TV: " + String.valueOf(roundedAverageRating));
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                // Handle the error if any occurred during the retrieval
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Backendless.Data.of(Participant.class).find(new AsyncCallback<List<Participant>>() {
            @Override
            public void handleResponse(List<Participant> participants) {
                int totalParticipants = participants.size();
                int totalRatings = 0;

                for (Participant participant : participants) {
                    String ratingString = participant.getListenRadio();
                    int rating = extractRatingFromRatingString(ratingString);
                    totalRatings += rating;
                }

                Participant firstParticipant = participants.get(0);
                int count = firstParticipant.getCount();

                double averageRating = (double) totalRatings / count;
                double roundedAverageRating = Math.round(averageRating * 10.0) / 10.0;

                tvListenRadio.setText("People like to listen to the radio: " + String.valueOf(roundedAverageRating));
            }

            @Override
            public void handleFault(BackendlessFault fault) {
                Toast.makeText(Results.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                showProgress(false);
            }
        });

        btnOk = findViewById(R.id.btnOK);

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Results.this, MainActivity.class));
                Results.this.finish();
            }
        });
    }
    private int extractRatingFromRatingString(String ratingString) {

        String cleanRatingString = ratingString.replaceAll("\\s", "").replaceAll("\\(|\\)", "");

        String[] parts = cleanRatingString.split(",");

        String ratingNumberString = parts[0].replaceAll("[^0-9]", "");
        return Integer.parseInt(ratingNumberString);
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });

            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }
}