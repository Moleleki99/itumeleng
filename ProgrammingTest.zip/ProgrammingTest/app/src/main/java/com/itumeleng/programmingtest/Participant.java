package com.itumeleng.programmingtest;

import java.util.Date;

public class Participant {

    private String surname;
    private String name;
    private int contactNumber;
    private String date;
    private int age;

    private boolean pizza;
    private boolean pasta;
    private boolean papWors;
    private boolean chicken;
    private boolean beef;
    private boolean other;

    private String eatOut;
    private String watchMovies;
    private String watchTV;
    private String listenRadio;

    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(int contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isPizza() {
        return pizza;
    }

    public void setPizza(boolean pizza) {
        this.pizza = pizza;
    }

    public boolean isPasta() {
        return pasta;
    }

    public void setPasta(boolean pasta) {
        this.pasta = pasta;
    }

    public boolean isPapWors() {
        return papWors;
    }

    public void setPapWors(boolean papWors) {
        this.papWors = papWors;
    }

    public boolean isChicken() {
        return chicken;
    }

    public void setChicken(boolean chicken) {
        this.chicken = chicken;
    }

    public boolean isBeef() {
        return beef;
    }

    public void setBeef(boolean beef) {
        this.beef = beef;
    }

    public boolean isOther() {
        return other;
    }

    public void setOther(boolean other) {
        this.other = other;
    }

    public String getEatOut() {
        return eatOut;
    }

    public void setEatOut(String eatOut) {
        this.eatOut = eatOut;
    }

    public String getWatchMovies() {
        return watchMovies;
    }

    public void setWatchMovies(String watchMovies) {
        this.watchMovies = watchMovies;
    }

    public String getWatchTV() {
        return watchTV;
    }

    public void setWatchTV(String watchTV) {
        this.watchTV = watchTV;
    }

    public String getListenRadio() {
        return listenRadio;
    }

    public void setListenRadio(String listenRadio) {
        this.listenRadio = listenRadio;
    }
}
